using Mono.Data.Sqlite;
using System.Data;
using System.IO;
using UnityEngine;
using System.Text;
using System.Collections.Generic;
using System.Globalization;

public class CreateDatabase : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //Create database
        string connection = "URI=file:" + Application.persistentDataPath + "/QuestionDatabase";

        //Set up connection
        IDbConnection dbcon = new SqliteConnection(connection);

        //Load files with questions
        DirectoryInfo questionsDirectory = new DirectoryInfo(@"Assets\Quiz\TextFiles");
        FileInfo[] files = questionsDirectory.GetFiles("*.txt");

        //Create tables for questions
        CreateTables(files, dbcon);

        //Insert questions into database
        InsertQuestions(files, questionsDirectory, dbcon);
    }

    void CreateTables(FileInfo[] files, IDbConnection dbcon)
    {
        foreach (FileInfo file in files)
        {
            //Get name of file 
            string name = file.Name.Substring(0, file.Name.Length - 4);

            //Open connection
            dbcon.Open();

            //Create table
            IDbCommand dbcmd;
            dbcmd = dbcon.CreateCommand();
            string q_createTable = "CREATE TABLE IF NOT EXISTS '" + name + "'(" +
                                   "Id                  INTEGER PRIMARY KEY AUTOINCREMENT," +
                                   "Question            TEXT NOT NULL," +
                                   "RightAnswer         TEXT NOT NULL," +
                                   "WrongAnswerOne      TEXT NOT NULL," +
                                   "WrongAnswerTwo      TEXT NOT NULL," +
                                   "WrongAnswerThree    TEXT NOT NULL" +
                                   ")";

            dbcmd.CommandText = q_createTable;
            dbcmd.ExecuteReader();

            //Close connection
            dbcon.Close();
        }
    }

    void InsertQuestions(FileInfo[] files, DirectoryInfo questionsDirectory, IDbConnection dbcon)
    {
        foreach (FileInfo file in files)
        {
            //Get name of file 
            string name = file.Name.Substring(0, file.Name.Length - 4);

            //Load all lines in a file 
            string[] lines = File.ReadAllLines(questionsDirectory + @"\" + file.Name, Encoding.GetEncoding(1250));

            foreach (string line in lines)
            {
                //Split line into question and answers
                string[] question = line.Split(';');

                if (question.Length == 5)
                {
                    //Open connection
                    dbcon.Open();

                    //Check if question is in table
                    IDbCommand dbcmd;
                    dbcmd = dbcon.CreateCommand();
                    string q_checkQuestion = "SELECT * FROM '" + name +"' WHERE Question = '"+ question[0] +"'";
                    dbcmd.CommandText = q_checkQuestion;
                    
                    if (dbcmd.ExecuteScalar() == null)
                    {
                        //Insert question
                        dbcmd = dbcon.CreateCommand();
                        string q_insertQuestion = "INSERT INTO '" + name + "' (Question, RightAnswer, WrongAnswerOne, WrongAnswerTwo, WrongAnswerThree) " +
                                                  "VALUES (" +
                                                  "'" + question[0] + "'," +
                                                  "'" + question[1] + "'," +
                                                  "'" + question[2] + "'," +
                                                  "'" + question[3] + "'," +
                                                  "'" + question[4] + "'" +
                                                  ")";

                        dbcmd.CommandText = q_insertQuestion;
                        dbcmd.ExecuteReader();
                    }                    

                    //Close connection
                    dbcon.Close();
                }
            }            
        }
    }
}
