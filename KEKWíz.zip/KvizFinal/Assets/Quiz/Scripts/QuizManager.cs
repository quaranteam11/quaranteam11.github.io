using Mono.Data.Sqlite;
using System;
using System.Data;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuizManager : MonoBehaviour
{
    [SerializeField] private QuizUI quizUI;
    [SerializeField] private List<QuizDataScriptable> quizData;
    
    private List<Question> questions;
    private Question selectedQuestion;
    private int scoreCount = 0;
    public float currentTime;
    private int lifeRemaining = 3;

    private GameStatus gameStatus = GameStatus.Next;

    public GameStatus GameStatus { get { return gameStatus;}} 
 
    // Start is called before the first frame update
    public void StartGame(int index)
    {
        currentTime = 600;
        SetTimer(currentTime);
        scoreCount = 0;
        lifeRemaining = 3;
        questions = new List<Question>();

        LoadQuestions(index);

        for (int i = 0; i < quizData[index].questions.Count; i++)
        {
            questions.Add(quizData[index].questions[i]);
        }
       
       selectQuestion();
       gameStatus = GameStatus.Playing;
    }

    public void LoadQuestions(int i)
    {
        string tableName = "";
        switch (i)
        {
            case 0:
                tableName = "CJL";
                break;
            case 1:
                tableName = "POG";
                break;
            case 2:
                tableName = "POSSOS";
                break;
            case 3:
                tableName = "PRG";
                break;
            case 4:
                tableName = "PVY";
                break;
        }

        //Set up Connection
        string connection = "URI=file:" + Application.persistentDataPath + "/QuestionDatabase";
        IDbConnection dbcon = new SqliteConnection(connection);

        //Open connection
        dbcon.Open();

        //Select questions
        IDbCommand dbcmd;
        dbcmd = dbcon.CreateCommand();
        string q_questions = "SELECT Question, RightAnswer, WrongAnswerOne, WrongAnswerTwo, WrongAnswerThree FROM '" + tableName + "';";

        //Clear list

        quizData[i].questions.Clear();

        dbcmd.CommandText = q_questions;
        IDataReader reader = dbcmd.ExecuteReader();
        while (reader.Read())
        {
            //Load questions
            Question question = new Question();
            List<string> options = new List<string>();
            options.Add(reader[1].ToString());
            options.Add(reader[2].ToString());
            options.Add(reader[3].ToString());
            options.Add(reader[4].ToString());
            question.questionInfo = reader[0].ToString();
            question.questionType = QuestionType.TEXT;
            question.options = options;
            question.correctAns = reader[1].ToString();
            quizData[i].questions.Add(question);
        }

        //Close connection
        dbcon.Close();
    }

    public void selectQuestion()
    {
        int val = UnityEngine.Random.Range(0, questions.Count);
        selectedQuestion = questions[val];
        quizUI.SetQuestion(selectedQuestion);
        questions.RemoveAt(val);
    }


    private void Update()
    {
        if(gameStatus == GameStatus.Playing)
        {
            currentTime -= Time.deltaTime;
            SetTimer(currentTime);
        }
    }

    public void SetTimer(float value)
    {
        TimeSpan time = TimeSpan.FromSeconds(value);
        quizUI.TimerText.text = "Čas: " + time.ToString("mm':'ss");

        if(currentTime <= 0)
        {
           gameStatus = GameStatus.Next;
           quizUI.GameOverPanel.SetActive(true); 
        } 
    } 

    public bool Answer(string answered)
    {
        bool correctAns = false;

        if (answered == selectedQuestion.correctAns)
        {
            correctAns = true;
            scoreCount += 50;
            quizUI.ScoreText.text = "Skóre:" + scoreCount;
        }
        else
        {
            lifeRemaining--;
            quizUI.ReduceLife(lifeRemaining);

            if(lifeRemaining <= 0)
            {
                gameStatus = GameStatus.Next;
                quizUI.TotalScoreText.text = "Finální skóre:\n" + scoreCount;
                quizUI.GameOverPanel.SetActive(true);
            }
        }
        if (gameStatus == GameStatus.Playing)
        {
            if (questions.Count > 0)
            {
               //Invoke("SelectQuestion", 0.4f);
            }
            else
            {
                gameStatus = GameStatus.Next;
                quizUI.GameOverPanel.SetActive(true);
            }
        }
        
        return correctAns;
    }

    public void QuitGame()
    {
        Application.Quit();
        Debug.Log("Ukončeno bez problémů jak šéf");
    }

}

[System.Serializable]
public class Question
{
    public string questionInfo;
    public QuestionType questionType;
    public Sprite questionImg;
    public List<string> options;
    public string correctAns;
}

[System.Serializable]
public enum QuestionType
{
    TEXT,
    IMAGE
}
 
 
[System.Serializable]
public enum GameStatus
{
    Playing,
    Next
}